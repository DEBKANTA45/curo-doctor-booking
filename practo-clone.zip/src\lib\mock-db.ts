import {
  Account,
  Appointment,
  Doctor,
  DoctorAccount,
  Notification,
  PatientAccount,
  PatientProfile,
  Review,
} from "./types";
import { doctors as seedDoctors, reviews as seedReviews } from "./utils";

const ACCOUNTS_KEY = "curo_accounts";
const SESSION_KEY = "curo_session";
const APPOINTMENTS_KEY = "curo_appointments";
const CUSTOM_DOCTORS_KEY = "curo_custom_doctors";
const PATIENT_PROFILES_KEY = "curo_patient_profiles";
const NOTIFICATIONS_KEY = "curo_notifications";
const CUSTOM_REVIEWS_KEY = "curo_custom_reviews";

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, JSON.stringify(value));
}

function slugify(name: string) {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

// ---------- Accounts ----------

export function getAccounts(): Account[] {
  return read<Account[]>(ACCOUNTS_KEY, []);
}

export function findAccountByEmail(email: string): Account | undefined {
  const target = email.trim().toLowerCase();
  return getAccounts().find((a) => a.email.trim().toLowerCase() === target);
}

export function registerPatient(data: {
  name: string;
  email: string;
  password: string;
  phone: string;
}): { ok: boolean; error?: string; account?: PatientAccount } {
  const email = data.email.trim();
  if (findAccountByEmail(email)) {
    return { ok: false, error: "An account with this email already exists." };
  }
  const account: PatientAccount = {
    id: `p_${Date.now()}`,
    role: "patient",
    name: data.name.trim(),
    email,
    password: data.password,
    phone: data.phone.trim(),
  };
  const accounts = getAccounts();
  accounts.push(account);
  write(ACCOUNTS_KEY, accounts);
  setSession(account);
  return { ok: true, account };
}

export function registerDoctor(data: {
  name: string;
  email: string;
  password: string;
  specialtyId: string;
  specialty: string;
  city: string;
  clinicName: string;
  consultationFee: number;
  experienceYears: number;
  about?: string;
}): { ok: boolean; error?: string; account?: DoctorAccount } {
  const email = data.email.trim();
  if (findAccountByEmail(email)) {
    return { ok: false, error: "An account with this email already exists." };
  }

  const doctorId = `custom_${Date.now()}`;
  const slug = `${slugify(data.name) || "doctor"}-${Date.now().toString(36)}`;

  const newDoctor: Doctor = {
    id: doctorId,
    slug,
    name: data.name.trim(),
    gender: "male",
    specialtyId: data.specialtyId,
    specialty: data.specialty,
    qualifications: "MBBS",
    experienceYears: data.experienceYears,
    rating: 0,
    reviewCount: 0,
    consultationFee: data.consultationFee,
    clinicName: data.clinicName.trim(),
    locality: "",
    city: data.city.trim(),
    languages: ["English"],
    about:
      data.about?.trim() ||
      `${data.name.trim()} is a ${data.specialty} available for consultations on Curo.`,
    photo: `https://i.pravatar.cc/300?u=${encodeURIComponent(email)}`,
    verified: false,
    nextAvailable: "Today",
    availableDays: ["Mon", "Tue", "Wed", "Thu", "Fri"],
    slots: ["10:00 AM", "11:00 AM", "04:00 PM", "05:00 PM"],
  };

  const customDoctors = getCustomDoctors();
  customDoctors.push(newDoctor);
  write(CUSTOM_DOCTORS_KEY, customDoctors);

  const account: DoctorAccount = {
    id: `dr_${Date.now()}`,
    role: "doctor",
    name: data.name.trim(),
    email,
    password: data.password,
    specialty: data.specialty,
    doctorId,
  };
  const accounts = getAccounts();
  accounts.push(account);
  write(ACCOUNTS_KEY, accounts);
  setSession(account);
  return { ok: true, account };
}

export function login(
  email: string,
  password: string,
  expectedRole: "patient" | "doctor"
): { ok: boolean; error?: string; account?: Account } {
  const account = findAccountByEmail(email);
  if (!account) return { ok: false, error: "No account found with this email." };
  if (account.role !== expectedRole) {
    return {
      ok: false,
      error: `This email is registered as a ${account.role}. Please use the ${account.role} login.`,
    };
  }
  if (account.password !== password) {
    return { ok: false, error: "Incorrect password." };
  }
  setSession(account);
  return { ok: true, account };
}

export function setSession(account: Account) {
  write(SESSION_KEY, account);
}

export function getSession(): Account | null {
  return read<Account | null>(SESSION_KEY, null);
}

export function logout() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(SESSION_KEY);
}

// ---------- Doctors (seeded + self-registered) ----------

export function getCustomDoctors(): Doctor[] {
  return read<Doctor[]>(CUSTOM_DOCTORS_KEY, []);
}

export function getAllDoctors(): Doctor[] {
  return [...seedDoctors, ...getCustomDoctors()];
}

export function getCustomDoctorById(id: string): Doctor | undefined {
  return getCustomDoctors().find((d) => d.id === id);
}

export function updateCustomDoctor(id: string, updates: Partial<Doctor>): Doctor | null {
  const all = getCustomDoctors();
  const index = all.findIndex((d) => d.id === id);
  if (index === -1) return null;
  const updated = { ...all[index], ...updates };
  all[index] = updated;
  write(CUSTOM_DOCTORS_KEY, all);
  return updated;
}

// ---------- Patient profile (medical info, contact details) ----------

export function getPatientProfile(email: string): PatientProfile | null {
  const all = read<Record<string, PatientProfile>>(PATIENT_PROFILES_KEY, {});
  return all[email.trim().toLowerCase()] ?? null;
}

export function savePatientProfile(profile: PatientProfile) {
  const all = read<Record<string, PatientProfile>>(PATIENT_PROFILES_KEY, {});
  all[profile.email.trim().toLowerCase()] = profile;
  write(PATIENT_PROFILES_KEY, all);
}

// ---------- Appointments ----------

export function getAppointments(): Appointment[] {
  return read<Appointment[]>(APPOINTMENTS_KEY, []);
}

export function getAppointmentsForPatient(email: string): Appointment[] {
  const target = email.trim().toLowerCase();
  return getAppointments().filter((a) => a.patientEmail.trim().toLowerCase() === target);
}

export function getAppointmentsForDoctor(doctorName: string): Appointment[] {
  return getAppointments().filter((a) => a.doctorName === doctorName);
}

export interface DoctorPatientSummary {
  name: string;
  email: string;
  visitCount: number;
  completedVisitCount: number;
  lastVisitAt: string;
}

// Unique patients this doctor has ever had an appointment with, newest activity first.
export function getPatientsForDoctor(doctorName: string): DoctorPatientSummary[] {
  const appts = getAppointmentsForDoctor(doctorName);
  const map = new Map<string, DoctorPatientSummary>();

  for (const a of appts) {
    const key = a.patientEmail.trim().toLowerCase();
    const activityAt = a.consultedAt ?? a.date;
    const existing = map.get(key);
    if (!existing) {
      map.set(key, {
        name: a.patientName,
        email: a.patientEmail,
        visitCount: 1,
        completedVisitCount: a.status === "completed" ? 1 : 0,
        lastVisitAt: activityAt,
      });
    } else {
      existing.visitCount += 1;
      if (a.status === "completed") existing.completedVisitCount += 1;
      if (activityAt > existing.lastVisitAt) existing.lastVisitAt = activityAt;
    }
  }

  return Array.from(map.values()).sort((a, b) => b.lastVisitAt.localeCompare(a.lastVisitAt));
}

export function findPatientForDoctor(
  doctorName: string,
  patientEmail: string
): DoctorPatientSummary | undefined {
  const target = patientEmail.trim().toLowerCase();
  return getPatientsForDoctor(doctorName).find((p) => p.email.trim().toLowerCase() === target);
}

// Completed visits only (i.e. ones with a diagnosis/prescription on record), newest first.
export function getVisitHistoryForDoctorAndPatient(
  doctorName: string,
  patientEmail: string
): Appointment[] {
  const target = patientEmail.trim().toLowerCase();
  return getAppointmentsForDoctor(doctorName)
    .filter((a) => a.patientEmail.trim().toLowerCase() === target && a.status === "completed")
    .sort((a, b) => {
      const aKey = a.consultedAt ?? a.date;
      const bKey = b.consultedAt ?? b.date;
      return bKey.localeCompare(aKey);
    });
}

export function createAppointment(
  appt: Omit<Appointment, "id" | "createdAt" | "status">
): Appointment {
  const full: Appointment = {
    ...appt,
    id: `apt_${Date.now()}`,
    status: "upcoming",
    createdAt: new Date().toISOString(),
  };
  const all = getAppointments();
  all.unshift(full);
  write(APPOINTMENTS_KEY, all);
  return full;
}

export function cancelAppointment(id: string) {
  const all = getAppointments().map((a) =>
    a.id === id ? { ...a, status: "cancelled" as const } : a
  );
  write(APPOINTMENTS_KEY, all);
}

export function rescheduleAppointment(id: string, newDate: string): Appointment | null {
  const all = getAppointments();
  const index = all.findIndex((a) => a.id === id);
  if (index === -1) return null;
  const previous = all[index];
  if (previous.date === newDate) return previous;

  const updated: Appointment = { ...previous, date: newDate };
  all[index] = updated;
  write(APPOINTMENTS_KEY, all);

  addNotification(
    previous.patientEmail,
    `${previous.doctorName} rescheduled your appointment from ${previous.date} to ${newDate}.`
  );
  return updated;
}

export function getAppointmentById(id: string): Appointment | undefined {
  return getAppointments().find((a) => a.id === id);
}

export function completeAppointment(
  id: string,
  data: { diagnosis: string; report: string; medicines: string }
): Appointment | null {
  const all = getAppointments();
  const index = all.findIndex((a) => a.id === id);
  if (index === -1) return null;
  const updated: Appointment = {
    ...all[index],
    status: "completed",
    diagnosis: data.diagnosis,
    report: data.report,
    medicines: data.medicines,
    consultedAt: new Date().toISOString(),
  };
  all[index] = updated;
  write(APPOINTMENTS_KEY, all);
  return updated;
}

// ---------- Notifications ----------

export function getNotifications(email: string): Notification[] {
  const target = email.trim().toLowerCase();
  return read<Notification[]>(NOTIFICATIONS_KEY, [])
    .filter((n) => n.email.trim().toLowerCase() === target)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function getUnreadNotificationCount(email: string): number {
  return getNotifications(email).filter((n) => !n.read).length;
}

export function addNotification(email: string, message: string) {
  const all = read<Notification[]>(NOTIFICATIONS_KEY, []);
  all.push({
    id: `note_${Date.now()}`,
    email,
    message,
    read: false,
    createdAt: new Date().toISOString(),
  });
  write(NOTIFICATIONS_KEY, all);
}

export function markAllNotificationsRead(email: string) {
  const target = email.trim().toLowerCase();
  const all = read<Notification[]>(NOTIFICATIONS_KEY, []);
  write(
    NOTIFICATIONS_KEY,
    all.map((n) => (n.email.trim().toLowerCase() === target ? { ...n, read: true } : n))
  );
}

export function dismissNotification(id: string) {
  const all = read<Notification[]>(NOTIFICATIONS_KEY, []);
  write(NOTIFICATIONS_KEY, all.filter((n) => n.id !== id));
}

// ---------- Reviews (seeded + patient-submitted) ----------

export function getCustomReviews(doctorId?: string): Review[] {
  const all = read<Review[]>(CUSTOM_REVIEWS_KEY, []);
  return doctorId ? all.filter((r) => r.doctorId === doctorId) : all;
}

export function hasReviewedAppointment(appointmentId: string): boolean {
  return getCustomReviews().some((r) => r.appointmentId === appointmentId);
}

export function addReview(review: Omit<Review, "id">): Review {
  const full: Review = { ...review, id: `rev_${Date.now()}` };
  const all = getCustomReviews();
  all.unshift(full);
  write(CUSTOM_REVIEWS_KEY, all);
  return full;
}

export function getAllReviewsForDoctor(doctorId: string): Review[] {
  const seeded = seedReviews.filter((r) => r.doctorId === doctorId);
  const custom = getCustomReviews(doctorId);
  return [...custom, ...seeded];
}

// Blends the doctor's baseline rating/review count with any freshly
// submitted patient reviews, so new reviews move the average without
// needing full historical review data for the seeded baseline.
export function getRatingSummary(doctor: Doctor): { rating: number; reviewCount: number } {
  const custom = getCustomReviews(doctor.id);
  if (custom.length === 0) return { rating: doctor.rating, reviewCount: doctor.reviewCount };

  const baselineScore = doctor.rating * doctor.reviewCount;
  const customScore = custom.reduce((sum, r) => sum + r.rating, 0);
  const totalCount = doctor.reviewCount + custom.length;
  const rating = totalCount > 0 ? Math.round(((baselineScore + customScore) / totalCount) * 10) / 10 : 0;

  return { rating, reviewCount: totalCount };
}